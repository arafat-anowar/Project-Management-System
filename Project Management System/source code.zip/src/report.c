/*
    NAME : FAIZA LABIBA
    ID : 2026-2-60-013
*/
#include "report.h"

// report main source code start

int project_summary_report()
{
    // declare all variables
    struct p_details project;
    char path[MAX_PATH_LENGTH], row[MAX_LENGTH_OF_DATA_IN_FILE], *field;
    int total_projects = ZERO, created_projects = ZERO, in_progress_projects = ZERO, completed_projects = ZERO, cancelled_projects = ZERO, terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 19, x, y;
    FILE *projectDBS_open;

    // get project database path
    get_path(path);
    strcat(path, PROJECT_DATABASE_FILE);

    // open database
    projectDBS_open = fopen(path, FILE_MODE_READ);
    if (projectDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), projectDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        strcpy(project.id, field);

        field = strtok(NULL, ",");
        strcpy(project.category, field);

        field = strtok(NULL, ",");
        strcpy(project.name, field);

        field = strtok(NULL, ",");
        strcpy(project.description, field);

        field = strtok(NULL, ",");
        strcpy(project.priority, field);

        field = strtok(NULL, ",");
        strcpy(project.status, field);

        field = strtok(NULL, ",");
        strcpy(project.start_date, field);

        field = strtok(NULL, ",");
        strcpy(project.end_date, field);

        field = strtok(NULL, ",");
        strcpy(project.created_by, field);

        total_projects++;

        if (strcmp(project.status, DEFAULT_PROJECT_STATUS) == ZERO)
        {
            created_projects++;
        }
        else if (strcmp(project.status, IN_PROGRESS_PROJECT_STATUS) == ZERO)
        {
            in_progress_projects++;
        }
        else if (strcmp(project.status, COMPLETED_PROJECT_STATUS) == ZERO)
        {
            completed_projects++;
        }
        else if (strcmp(project.status, CANCELLED_PROJECT_STATUS) == ZERO)
        {
            cancelled_projects++;
        }
    }

    // close database
    if (fclose(projectDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    // set terminal to UTF8
    init_console();
    header_screen();

    // measure terminal height and width also x and y coordinate
    terminal_width = get_console_width();
    terminal_height = get_console_height();
    x = (terminal_width - box_width) / TWO;
    y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

    project_summary_report_screen(x, y);

    // print project details
    move_cursor(x + 30, y + 4);
    printf("%d", total_projects);

    move_cursor(x + 30, y + 6);
    printf("%d", created_projects);

    move_cursor(x + 30, y + 8);
    printf("%d", in_progress_projects);

    move_cursor(x + 30, y + 10);
    printf("%d", completed_projects);

    move_cursor(x + 30, y + 12);
    printf("%d", cancelled_projects);

    move_cursor(x + 45, y + 15);
    get_input;

    return 0;
}

int project_progress_report()
{
    // declare all variables
    struct p_details project;
    struct t_details task;
    char project_path[MAX_PATH_LENGTH], task_path[TASK_PATH_BUFFER_SIZE], project_row[MAX_LENGTH_OF_DATA_IN_FILE], task_row[TASK_FILE_DATA_SIZE], project_file_name[PROJECT_FILE_NAME_SIZE], category_file_name[PROJECT_FILE_NAME_SIZE], *field;
    int total_tasks = ZERO, completed_tasks = ZERO, project_found = ZERO, terminal_width = ZERO, terminal_height = ZERO, box_width = CONTAINER_WIDTH, box_height = 16, x = ZERO, y = ZERO;
    float progress = 0.0f;
    FILE *projectDBS_open, *taskDBS_open;

    // get project database path
    get_path(project_path);
    strcat(project_path, PROJECT_DATABASE_FILE);

    // open project database
    projectDBS_open = fopen(project_path, FILE_MODE_READ);

    if (projectDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read all projects
    while (fgets(project_row, sizeof(project_row), projectDBS_open) != NULL)
    {
        // remove newline
        project_row[strcspn(project_row, "\n")] = '\0';
        project_row[strcspn(project_row, "\r")] = '\0';

        // reset
        total_tasks = ZERO;
        completed_tasks = ZERO;
        progress = 0.0f;
        project_found = ZERO;

        // tokenize data
        field = strtok(project_row, ",");
        strcpy(project.id, field);

        field = strtok(NULL, ",");
        strcpy(project.name, field);

        field = strtok(NULL, ",");
        strcpy(project.category, field);

        field = strtok(NULL, ",");
        strcpy(project.description, field);

        field = strtok(NULL, ",");
        strcpy(project.priority, field);

        field = strtok(NULL, ",");
        strcpy(project.status, field);

        field = strtok(NULL, ",");
        strcpy(project.start_date, field);

        field = strtok(NULL, ",");
        strcpy(project.end_date, field);

        field = strtok(NULL, ",");
        strcpy(project.created_by, field);

        project_found = 1;

        // get project task database path
        get_path(task_path);
        strcat(task_path, PROJECTS_FOLDER);
        strcat(task_path, "\\");

        // get project file name from project name
        strcpy(project_file_name, project.name);
        strlwr(project_file_name);
        strcat(task_path, project_file_name);
        strcat(task_path, TASK_FILE_EXTENSION);

        // open project task database
        taskDBS_open = fopen(task_path, FILE_MODE_READ);
        // if project name file does not exist
        if (taskDBS_open == NULL)
        {
            // create alternative file name from category
            strcpy(category_file_name, project.category);

            // convert category to lowercase
            strlwr(category_file_name);

            // get project task database path again
            get_path(task_path);
            strcat(task_path, PROJECTS_FOLDER);
            strcat(task_path, "\\");
            strcat(task_path, category_file_name);
            strcat(task_path, TASK_FILE_EXTENSION);

            // open category based project task database
            taskDBS_open = fopen(task_path, FILE_MODE_READ);
        }

        // read project task database
        if (taskDBS_open != NULL)
        {
            while (fgets(task_row, sizeof(task_row), taskDBS_open) != NULL)
            {
                // remove newline
                task_row[strcspn(task_row, "\n")] = '\0';
                task_row[strcspn(task_row, "\r")] = '\0';

                // tokenize data
                field = strtok(task_row, ",");
                strcpy(task.task_id, field);

                field = strtok(NULL, ",");
                strcpy(task.project_id, field);

                field = strtok(NULL, ",");
                strcpy(task.name, field);

                field = strtok(NULL, ",");
                strcpy(task.description, field);

                field = strtok(NULL, ",");
                strcpy(task.priority, field);

                field = strtok(NULL, ",");
                strcpy(task.status, field);

                field = strtok(NULL, ",");
                strcpy(task.start_date, field);

                field = strtok(NULL, ",");
                strcpy(task.end_date, field);

                field = strtok(NULL, ",");
                strcpy(task.created_by, field);

                if (strcmp(task.project_id, project.id) == ZERO)
                {
                    // count total task
                    total_tasks++;
                    // count completed task
                    if (strcmp(task.status, COMPLETED_TASK_STATUS) == ZERO)
                    {
                        completed_tasks++;
                    }
                }
            }
            // close project task database
            if (fclose(taskDBS_open) == EOF)
            {
                something_went_wrong_screen(FILE_CLOSE_ERROR);
            }
        }

        // calculate project progress
        if (total_tasks > ZERO)
        {
            progress = ((float)completed_tasks * 100.0f) / (float)total_tasks;
        }
        else
        {
            progress = 0.0f;
        }

        // set terminal to UTF8
        init_console();
        header_screen();

        // measure terminal height and width also x and y coordinate
        terminal_width = get_console_width();
        terminal_height = get_console_height();

        x = (terminal_width - box_width) / TWO;
        y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

        // show project progress report screen
        project_progress_report_screen(x, y);

        // print project id
        move_cursor(x + 27, y + 4);
        printf("%s", project.id);

        // print project name
        move_cursor(x + 27, y + 6);
        printf("%s", project.name);

        // print total tasks
        move_cursor(x + 27, y + 8);
        printf("%d", total_tasks);

        // print completed tasks
        move_cursor(x + 27, y + 10);
        printf("%d", completed_tasks);

        // print progress
        move_cursor(x + 27, y + 12);
        printf("%.2f%%", progress);

        move_cursor(x + 45, y + 13);
        get_input;
    }

    // close project database
    if (fclose(projectDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

int overdue_projects_report()
{
    // declare all variables
    struct p_details project;
    char path[MAX_PATH_LENGTH], row[MAX_LENGTH_OF_DATA_IN_FILE], *field, today[PROJECT_END_DATE_SIZE];
    int terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 17, x, y;
    FILE *projectDBS_open;

    // get current date
    current_date(today);

    // get project database path
    get_path(path);
    strcat(path, PROJECT_DATABASE_FILE);

    // open database
    projectDBS_open = fopen(path, FILE_MODE_READ);
    if (projectDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), projectDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        strcpy(project.id, field);

        field = strtok(NULL, ",");
        strcpy(project.category, field);

        field = strtok(NULL, ",");
        strcpy(project.name, field);

        field = strtok(NULL, ",");
        strcpy(project.description, field);

        field = strtok(NULL, ",");
        strcpy(project.priority, field);

        field = strtok(NULL, ",");
        strcpy(project.status, field);

        field = strtok(NULL, ",");
        strcpy(project.start_date, field);

        field = strtok(NULL, ",");
        strcpy(project.end_date, field);

        field = strtok(NULL, ",");
        strcpy(project.created_by, field);

        if (strcmp(project.end_date, today) < ZERO && strcmp(project.status, COMPLETED_PROJECT_STATUS) != ZERO && strcmp(project.status, CANCELLED_PROJECT_STATUS) != ZERO)
        {
            // set terminal UTF8
            init_console();
            header_screen();

            // measure terminal height and width also x and y coordinate
            terminal_width = get_console_width();
            terminal_height = get_console_height();
            x = (terminal_width - box_width) / TWO;
            y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

            overdue_projects_report_screen(x, y);

            // print project details
            move_cursor(x + 24, y + 4);
            printf("%s", project.id);

            move_cursor(x + 24, y + 6);
            printf("%s", project.name);

            move_cursor(x + 24, y + 8);
            printf("%s", project.priority);

            move_cursor(x + 24, y + 10);
            printf("%s", project.status);

            move_cursor(x + 24, y + 12);
            printf("%s", project.end_date);

            move_cursor(x + 45, y + 13);
            get_input;
        }
    }

    // close database
    if (fclose(projectDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

int high_priority_projects_report()
{
    // declare all variables
    struct p_details project;
    char path[MAX_PATH_LENGTH], row[MAX_LENGTH_OF_DATA_IN_FILE], *field;
    int terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 17, x, y;
    FILE *projectDBS_open;

    // get project database path
    get_path(path);
    strcat(path, PROJECT_DATABASE_FILE);

    // open database
    projectDBS_open = fopen(path, FILE_MODE_READ);
    if (projectDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), projectDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        strcpy(project.id, field);

        field = strtok(NULL, ",");
        strcpy(project.category, field);

        field = strtok(NULL, ",");
        strcpy(project.name, field);

        field = strtok(NULL, ",");
        strcpy(project.description, field);

        field = strtok(NULL, ",");
        strcpy(project.priority, field);

        field = strtok(NULL, ",");
        strcpy(project.status, field);

        field = strtok(NULL, ",");
        strcpy(project.start_date, field);

        field = strtok(NULL, ",");
        strcpy(project.end_date, field);

        field = strtok(NULL, ",");
        strcpy(project.created_by, field);

        if (strcmp(project.priority, "High") == ZERO && strcmp(project.status, COMPLETED_PROJECT_STATUS) != ZERO && strcmp(project.status, CANCELLED_PROJECT_STATUS) != ZERO)
        {
            // set terminal UTF8
            init_console();
            header_screen();

            // measure terminal height and width also x and y coordinate
            terminal_width = get_console_width();
            terminal_height = get_console_height();
            x = (terminal_width - box_width) / TWO;
            y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

            high_priority_projects_report_screen(x, y);

            // print project details
            move_cursor(x + 24, y + 4);
            printf("%s", project.id);

            move_cursor(x + 24, y + 6);
            printf("%s", project.name);

            move_cursor(x + 24, y + 8);
            printf("%s", project.priority);

            move_cursor(x + 24, y + 10);
            printf("%s", project.status);

            move_cursor(x + 24, y + 12);
            printf("%s", project.end_date);

            move_cursor(x + 45, y + 13);
            get_input;
        }
    }

    // close database
    if (fclose(projectDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

int task_summary_report()
{
    // declare all variables
    struct t_details task;
    char path[TASK_PATH_BUFFER_SIZE], row[TASK_FILE_DATA_SIZE], *field;
    int total_tasks = ZERO, pending_tasks = ZERO, planning_tasks = ZERO, in_progress_tasks = ZERO, completed_tasks = ZERO, cancelled_tasks = ZERO, terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 17, x, y;
    FILE *taskDBS_open;

    // get task database path
    get_path(path);
    strcat(path, TASK_DATABASE_FILE);

    // open database
    taskDBS_open = fopen(path, FILE_MODE_READ);
    if (taskDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), taskDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        task.unique_id = atoi(field);

        field = strtok(NULL, ",");
        strcpy(task.task_id, field);

        field = strtok(NULL, ",");
        strcpy(task.project_id, field);

        field = strtok(NULL, ",");
        strcpy(task.name, field);

        field = strtok(NULL, ",");
        strcpy(task.description, field);

        field = strtok(NULL, ",");
        strcpy(task.priority, field);

        field = strtok(NULL, ",");
        strcpy(task.status, field);

        field = strtok(NULL, ",");
        strcpy(task.start_date, field);

        field = strtok(NULL, ",");
        strcpy(task.end_date, field);

        field = strtok(NULL, ",");
        strcpy(task.created_by, field);

        total_tasks++;

        if (strcmp(task.status, DEFAULT_TASK_STATUS) == ZERO)
        {
            pending_tasks++;
        }
        else if (strcmp(task.status, "Planning") == ZERO)
        {
            planning_tasks++;
        }
        else if (strcmp(task.status, "In_Progress") == ZERO)
        {
            in_progress_tasks++;
        }
        else if (strcmp(task.status, COMPLETED_TASK_STATUS) == ZERO)
        {
            completed_tasks++;
        }
        else if (strcmp(task.status, CANCELLED_TASK_STATUS) == ZERO)
        {
            cancelled_tasks++;
        }
    }

    // close database
    if (fclose(taskDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    // set terminal UTF8
    init_console();
    header_screen();

    // measure terminal height and width also x and y coordinate
    terminal_width = get_console_width();
    terminal_height = get_console_height();
    x = (terminal_width - box_width) / TWO;
    y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

    task_summary_report_screen(x, y);

    // print task details
    move_cursor(x + 30, y + 4);
    printf("%d", total_tasks);

    move_cursor(x + 30, y + 6);
    printf("%d", pending_tasks);

    move_cursor(x + 30, y + 8);
    printf("%d", planning_tasks);

    move_cursor(x + 30, y + 10);
    printf("%d", in_progress_tasks);

    move_cursor(x + 30, y + 12);
    printf("%d", completed_tasks);

    move_cursor(x + 30, y + 14);
    printf("%d", cancelled_tasks);

    move_cursor(x + 45, y + 16);
    get_input;

    return 0;
}

int overdue_tasks_report()
{
    // declare all variables
    struct t_details task;
    char path[TASK_PATH_BUFFER_SIZE], row[TASK_FILE_DATA_SIZE], *field, today[TASK_END_DATE_SIZE];
    int terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 16, x, y;
    FILE *taskDBS_open;

    // get current date
    current_date(today);

    // get task database path
    get_path(path);
    strcat(path, TASK_DATABASE_FILE);

    // open database
    taskDBS_open = fopen(path, FILE_MODE_READ);
    if (taskDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), taskDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        task.unique_id = atoi(field);

        field = strtok(NULL, ",");
        strcpy(task.task_id, field);

        field = strtok(NULL, ",");
        strcpy(task.project_id, field);

        field = strtok(NULL, ",");
        strcpy(task.name, field);

        field = strtok(NULL, ",");
        strcpy(task.description, field);

        field = strtok(NULL, ",");
        strcpy(task.priority, field);

        field = strtok(NULL, ",");
        strcpy(task.status, field);

        field = strtok(NULL, ",");
        strcpy(task.start_date, field);

        field = strtok(NULL, ",");
        strcpy(task.end_date, field);

        field = strtok(NULL, ",");
        strcpy(task.created_by, field);

        if (strcmp(task.end_date, today) < ZERO && strcmp(task.status, COMPLETED_TASK_STATUS) != ZERO && strcmp(task.status, CANCELLED_TASK_STATUS) != ZERO)
        {
            // set terminal to UTF8
            init_console();
            header_screen();

            // measure terminal height and width also x and y coordinate
            terminal_width = get_console_width();
            terminal_height = get_console_height();
            x = (terminal_width - box_width) / TWO;
            y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

            overdue_tasks_report_screen(x, y);

            // print task details
            move_cursor(x + 24, y + 4);
            printf("%s", task.task_id);

            move_cursor(x + 24, y + 6);
            printf("%s", task.name);

            move_cursor(x + 24, y + 8);
            printf("%s", task.project_id);

            move_cursor(x + 24, y + 10);
            printf("%s", task.priority);

            move_cursor(x + 24, y + 12);
            printf("%s", task.status);

            move_cursor(x + 24, y + 14);
            printf("%s", task.end_date);

            get_input;
        }
    }

    // close database
    if (fclose(taskDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

int high_priority_tasks_report()
{
    // declare all variables
    struct t_details task;
    char path[TASK_PATH_BUFFER_SIZE], row[TASK_FILE_DATA_SIZE], *field;
    int terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 16, x, y;
    FILE *taskDBS_open;

    // get task database path
    get_path(path);
    strcat(path, TASK_DATABASE_FILE);

    // open database
    taskDBS_open = fopen(path, FILE_MODE_READ);
    if (taskDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), taskDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        task.unique_id = atoi(field);

        field = strtok(NULL, ",");
        strcpy(task.task_id, field);

        field = strtok(NULL, ",");
        strcpy(task.project_id, field);

        field = strtok(NULL, ",");
        strcpy(task.name, field);

        field = strtok(NULL, ",");
        strcpy(task.description, field);

        field = strtok(NULL, ",");
        strcpy(task.priority, field);

        field = strtok(NULL, ",");
        strcpy(task.status, field);

        field = strtok(NULL, ",");
        strcpy(task.start_date, field);

        field = strtok(NULL, ",");
        strcpy(task.end_date, field);

        field = strtok(NULL, ",");
        strcpy(task.created_by, field);

        if (strcmp(task.priority, "High") == ZERO && strcmp(task.status, COMPLETED_TASK_STATUS) != ZERO && strcmp(task.status, CANCELLED_TASK_STATUS) != ZERO)
        {
            // set terminal to UTF8
            init_console();
            header_screen();

            // measure terminal height and width also x and y coordinate
            terminal_width = get_console_width();
            terminal_height = get_console_height();
            x = (terminal_width - box_width) / TWO;
            y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

            high_priority_tasks_report_screen(x, y);

            // print task details
            move_cursor(x + 24, y + 4);
            printf("%s", task.task_id);

            move_cursor(x + 24, y + 6);
            printf("%s", task.name);

            move_cursor(x + 24, y + 8);
            printf("%s", task.project_id);

            move_cursor(x + 24, y + 10);
            printf("%s", task.priority);

            move_cursor(x + 24, y + 12);
            printf("%s", task.status);

            move_cursor(x + 24, y + 14);
            printf("%s", task.end_date);

            get_input;
        }
    }

    // close database
    if (fclose(taskDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

int pending_active_tasks_report()
{
    // declare all variables
    struct t_details task;
    char path[TASK_PATH_BUFFER_SIZE], row[TASK_FILE_DATA_SIZE], *field;
    int terminal_width, terminal_height, box_width = CONTAINER_WIDTH, box_height = 16, x, y;
    FILE *taskDBS_open;

    // get task database path
    get_path(path);
    strcat(path, TASK_DATABASE_FILE);

    // open database
    taskDBS_open = fopen(path, FILE_MODE_READ);
    if (taskDBS_open == NULL)
    {
        something_went_wrong_screen(FILE_OPEN_ERROR);
        return 0;
    }

    // read database
    while (fgets(row, sizeof(row), taskDBS_open) != NULL)
    {
        row[strcspn(row, "\n")] = '\0';

        // tokenize data
        field = strtok(row, ",");
        task.unique_id = atoi(field);

        field = strtok(NULL, ",");
        strcpy(task.task_id, field);

        field = strtok(NULL, ",");
        strcpy(task.project_id, field);

        field = strtok(NULL, ",");
        strcpy(task.name, field);

        field = strtok(NULL, ",");
        strcpy(task.description, field);

        field = strtok(NULL, ",");
        strcpy(task.priority, field);

        field = strtok(NULL, ",");
        strcpy(task.status, field);

        field = strtok(NULL, ",");
        strcpy(task.start_date, field);

        field = strtok(NULL, ",");
        strcpy(task.end_date, field);

        field = strtok(NULL, ",");
        strcpy(task.created_by, field);

        if (strcmp(task.status, COMPLETED_TASK_STATUS) != ZERO && strcmp(task.status, CANCELLED_TASK_STATUS) != ZERO)
        {
            // set terminal to UTF8
            init_console();
            header_screen();

            // measure terminal height and width also x and y coordinate
            terminal_width = get_console_width();
            terminal_height = get_console_height();
            x = (terminal_width - box_width) / TWO;
            y = ((terminal_height - box_height) / TWO) + SCREEN_START_Y;

            pending_active_tasks_screen(x, y);

            // print task details
            move_cursor(x + 24, y + 4);
            printf("%s", task.task_id);

            move_cursor(x + 24, y + 6);
            printf("%s", task.name);

            move_cursor(x + 24, y + 8);
            printf("%s", task.project_id);

            move_cursor(x + 24, y + 10);
            printf("%s", task.priority);

            move_cursor(x + 24, y + 12);
            printf("%s", task.status);

            move_cursor(x + 24, y + 14);
            printf("%s", task.end_date);

            get_input;
        }
    }

    // close database
    if (fclose(taskDBS_open) == EOF)
    {
        something_went_wrong_screen(FILE_CLOSE_ERROR);
    }

    return 0;
}

// report main source code end